<script setup>
import Login from '@/components/LoginTemplate.vue';
</script>

<template>
  <Login />
</template>